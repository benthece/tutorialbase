create
    definer = root@localhost procedure get_maincategories()
BEGIN
    SELECT guid, name
    FROM categories
    WHERE parent_id IS NULL;
END;

