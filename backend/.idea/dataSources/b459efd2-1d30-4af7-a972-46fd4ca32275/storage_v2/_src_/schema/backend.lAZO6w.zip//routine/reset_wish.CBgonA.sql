create
    definer = root@localhost procedure reset_wish()
BEGIN
    UPDATE users SET wishes = 5 WHERE id != 0;
END;

