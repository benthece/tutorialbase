create
    definer = root@localhost procedure get_videos_for_subcategory(IN subcat_guid char(36), IN quantity int unsigned)
BEGIN
    DECLARE subcat_id INTEGER UNSIGNED;

    SELECT id INTO subcat_id FROM categories WHERE guid = subcat_guid;

    SELECT videos.guid, title, url, base_image_url
    FROM videos
             INNER JOIN video_category vc on videos.id = vc.video_id
             INNER JOIN categories c on vc.category_id = c.id
    WHERE c.id = subcat_id
    ORDER BY RAND()
    LIMIT quantity;
END;

