create
    definer = root@localhost procedure create_comment(IN usr_guid char(36), IN vid_guid char(36),
                                                      IN comm_text varchar(100))
BEGIN
    DECLARE uid INTEGER UNSIGNED;
    DECLARE vid INTEGER UNSIGNED;

    SELECT id INTO uid FROM users WHERE guid = usr_guid;
    SELECT id INTO vid FROM videos WHERE guid = vid_guid;

    INSERT INTO comments (guid, user_id, video_id, text, created_at)
    VALUES (uuid_v4s(),
            uid,
            vid,
            comm_text,
            NOW());
END;

