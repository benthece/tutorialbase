create
    definer = root@localhost procedure get_comments(IN vid_guid char(36), IN offset_val int unsigned)
BEGIN
    DECLARE vid INTEGER UNSIGNED;

    SELECT id INTO vid FROM videos WHERE guid = vid_guid;

    SELECT comments.guid, username, text, comments.created_at, comments.modified_at
    FROM comments
             INNER JOIN videos
                        ON videos.id = comments.video_id
             INNER JOIN users
                        ON users.id = comments.user_id
    WHERE videos.id = vid
      AND comments.is_deleted = 0
    ORDER BY 4
    LIMIT offset_val, 5;
END;

