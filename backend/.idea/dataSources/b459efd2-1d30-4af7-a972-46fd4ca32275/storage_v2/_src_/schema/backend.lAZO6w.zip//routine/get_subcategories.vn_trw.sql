create
    definer = root@localhost procedure get_subcategories(IN quantity mediumint unsigned)
BEGIN
    SELECT guid, name
    FROM categories
    WHERE parent_id IS NOT NULL
    LIMIT quantity;
END;

