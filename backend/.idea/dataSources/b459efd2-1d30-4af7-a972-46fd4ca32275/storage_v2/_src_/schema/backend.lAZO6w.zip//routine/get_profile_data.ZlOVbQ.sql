create
    definer = root@localhost procedure get_profile_data(IN user_guid char(36))
BEGIN
    DECLARE user_id INTEGER UNSIGNED;

    SELECT id INTO user_id FROM users WHERE guid = user_guid;

    SELECT users.guid, username, profile_pic_url, bg_image_url, bio
    FROM users
    WHERE users.id = user_id;
END;

