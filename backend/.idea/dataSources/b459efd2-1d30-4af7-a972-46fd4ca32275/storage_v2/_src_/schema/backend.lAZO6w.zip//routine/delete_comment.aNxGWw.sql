create
    definer = root@localhost procedure delete_comment(IN comm_guid char(36))
BEGIN
    DECLARE comm_id INTEGER UNSIGNED;

    SELECT id INTO comm_id FROM comments WHERE guid = comm_guid;

    UPDATE comments SET is_deleted = TRUE WHERE id = comm_id;
END;

