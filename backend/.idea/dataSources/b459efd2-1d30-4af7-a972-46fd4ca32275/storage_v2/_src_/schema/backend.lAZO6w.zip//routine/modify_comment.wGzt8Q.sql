create
    definer = root@localhost procedure modify_comment(IN comm_guid char(36), IN comm_text varchar(100))
BEGIN
    DECLARE comm_id INTEGER UNSIGNED;

    SELECT id INTO comm_id FROM comments WHERE guid = comm_guid;

    UPDATE comments SET text = comm_text WHERE id = comm_id;
    UPDATE comments SET modified_at = NOW() WHERE id = comm_id;
END;

