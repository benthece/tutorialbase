create
    definer = root@localhost procedure get_user_uploaded(IN user_guid char(36))
BEGIN
    DECLARE var_user_id INTEGER UNSIGNED;

    SELECT id INTO var_user_id FROM users WHERE guid = user_guid;

    SELECT guid, title, url, base_image_url
    FROM videos
    WHERE user_id = var_user_id;
END;

